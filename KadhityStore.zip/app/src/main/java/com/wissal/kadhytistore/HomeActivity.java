package com.wissal.kadhytistore;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    ProgressBar progressBar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        progressBar= findViewById(R.id.progressbar);
        progressBar.setVisibility((View.GONE));
        progressBar.setVisibility(View.VISIBLE);
        startActivity(new Intent(HomeActivity.this,Main2Activity.class));
        Toast.makeText(this, "Please Wait", Toast.LENGTH_SHORT).show();
        finish();


    }

    public void login(View view) {
        startActivity(new Intent(HomeActivity.this,Login.class));
    }

    public void registration(View view) {
        startActivity(new Intent(HomeActivity.this,Registration.class));
    }

}